package com.example.mo3_calculator_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val one = findViewById<Button>(R.id.one)
        val two = findViewById<Button>(R.id.two)
        val three = findViewById<Button>(R.id.three)
        val four = findViewById<Button>(R.id.four)
        val five = findViewById<Button>(R.id.five)
        val six = findViewById<Button>(R.id.six)
        val seven = findViewById<Button>(R.id.seven)
        val eight = findViewById<Button>(R.id.eight)
        val nine = findViewById<Button>(R.id.nine)
        val zero = findViewById<Button>(R.id.zero)
        val equal = findViewById<Button>(R.id.equals)
        val clear = findViewById<Button>(R.id.clear)
        val add = findViewById<Button>(R.id.addition)
        val subtract = findViewById<Button>(R.id.subtraction)
        val multiply = findViewById<Button>(R.id.multiplication)
        val divide = findViewById<Button>(R.id.division)
        var results = findViewById<TextView>(R.id.output)
        var myStr:String = ""
        var number1:Int = 0
        var number2:Int = 0
        var op:Char=' '

// set on-click listener
        one.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "1"
            else
                results.text=myStr+"1"
        }
        two.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "2"
            else
                results.text=myStr+"2"
        }
        three.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "3"
            else
                results.text=myStr+"3"
        }
        four.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "4"
            else
                results.text=myStr+"4"
        }
        five.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "5"
            else
                results.text=myStr+"5"
        }
        six.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "6"
            else
                results.text=myStr+"6"
        }
        seven.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "7"
            else
                results.text=myStr+"7"
        }
        eight.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "8"
            else
                results.text=myStr+"8"
        }
        nine.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "9"
            else
                results.text=myStr+"9"
        }
        zero.setOnClickListener {
            myStr= results.text as String
            if(myStr=="0")
                results.text = "0"
            else
                results.text=myStr+"0"
        }
        clear.setOnClickListener {
            results.text= " "
            number1 = 0
            number2 = 0
        }
        //operators and buttons

        add.setOnClickListener {
            myStr = results.text as String
            if(myStr=="0") {

                number1 = 0
                results.text = ""
                op = '+'
            }
            else {
                number1 = myStr.toInt()
                results.text=""
                op='+'
            }
        }
        subtract.setOnClickListener {
            myStr = results.text as String
            if(myStr=="0") {

                number1 = 0
                results.text = ""
                op = '-'
            }
            else {
                number1 = myStr.toInt()
                results.text=""
                op='-'
            }
        }
        multiply.setOnClickListener {
            myStr = results.text as String
            if(myStr=="0") {

                number1 = 0
                results.text = ""
                op = '*'
            }
            else {
                number1 = myStr.toInt()
                results.text=""
                op='*'
            }
        }
        divide.setOnClickListener {
            myStr = results.text as String
            if(myStr=="0") {

                number1 = 0
                results.text = ""
                op = '/'
            }
            else {
                number1 = myStr.toInt()
                results.text=""
                op='/'
            }
        }
        equal.setOnClickListener {
            var total:Int
            myStr= results.text as String

                number2 = myStr.toInt()
                if(op=='+')
                {
                    total=number1+number2
                    results.text=""+total
                }
                else if (op=='-')
            {
                total=number1-number2
                results.text=""+total
            }
                else if (op=='*')
                {
                    total=number1*number2
                    results.text=""+total
                }
                else if (op=='/') {
                    if (number2 == 0)
                        results.text = "Undefined"
                    else {

                        total = number1 / number2
                        results.text = "" + total
                    }
                }

        }
        }
    }
